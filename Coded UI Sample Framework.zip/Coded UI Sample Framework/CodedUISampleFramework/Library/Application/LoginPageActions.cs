﻿using Microsoft.VisualStudio.TestTools.UITesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodedUISampleFramework.Library.Application
{
    class LoginPageActions
    {
        public static void Login(string user,string password)
        {
            ObjectMapper.LoginPage.UIWelcomeInternetExploWindow.UIWelcomeDocument.UIUsernameEdit.WaitForControlExist();
            ObjectMapper.LoginPage.UIWelcomeInternetExploWindow.UIWelcomeDocument.UIUsernameEdit.Text = user;

            ObjectMapper.LoginPage.UIWelcomeInternetExploWindow.UIWelcomeDocument.UIPasswordEdit.WaitForControlExist();
            ObjectMapper.LoginPage.UIWelcomeInternetExploWindow.UIWelcomeDocument.UIPasswordEdit.Text = password;

            ObjectMapper.LoginPage.UIWelcomeInternetExploWindow.UIWelcomeDocument.UILoginButton.WaitForControlExist();
            Mouse.Click(ObjectMapper.LoginPage.UIWelcomeInternetExploWindow.UIWelcomeDocument.UILoginButton);
        }


    }
}
