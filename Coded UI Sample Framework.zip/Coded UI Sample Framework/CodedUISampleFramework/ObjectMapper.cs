﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodedUISampleFramework.UIMaps.LoginPageClasses;

namespace CodedUISampleFramework
{
    public class ObjectMapper
    {
        private static LoginPage loginPage;
   

        public static LoginPage LoginPage
        {
            get
            {
                if (loginPage == null)
                {
                    return new LoginPage();
                }
                return loginPage;
            }

            set { ObjectMapper.loginPage = value; }
        }

      }
    }

