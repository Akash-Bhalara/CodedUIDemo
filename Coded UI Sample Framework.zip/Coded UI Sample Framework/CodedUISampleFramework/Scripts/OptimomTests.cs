﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Input;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UITest.Extension;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using CodedUISampleFramework.Library;
using CodedUISampleFramework.UIMaps;
using CodedUISampleFramework.Config;
using CodedUISampleFramework.Library.Application;
using System.Threading;

namespace CodedUISampleFramework.Scripts
{
    /// <summary>
    /// Summary description for OptimomTests
    /// </summary>
    [CodedUITest]
    public class OptimomTests : TestBase
    {
        public OptimomTests()
        {
        }

        #region TestInitialize
        //Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public override void MyTestInitialize()
        {
            Console.WriteLine("Initialize");
            base.MyTestInitialize();
            BrowserWindow.CurrentBrowser = "chrome";
        }
        #endregion

        #region Scripts
        [TestMethod]
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV", "|DataDirectory|\\TestData\\Credentials.csv", "Credentials#csv", DataAccessMethod.Sequential)]
        public void VerifyLoginScenario()
        {
            string user=Data.GetValue("user");
            string password = Data.GetValue("password");
            BrowserWindow.Launch(new Uri("https://test.optiom.com"));
            LoginPageActions.Login(user, password);
            
        }

        #endregion

        //Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public override void MyTestCleanup()
        {
            base.MyTestCleanup();
        }
    }
}
